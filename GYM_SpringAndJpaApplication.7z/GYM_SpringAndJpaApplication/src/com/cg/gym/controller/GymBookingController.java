package com.cg.gym.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.gym.dao.IBookingDao;
import com.cg.gym.entities.Customer;
import com.cg.gym.service.IBookingService;
import com.sun.javafx.sg.prism.NGShape.Mode;
import com.sun.org.apache.regexp.internal.recompile;

@Controller
public class GymBookingController {

	@Autowired
	private IBookingService bookingService;

	public IBookingService getBookingService() {
		return bookingService;
	}

	public void setBookingService(IBookingService bookingService) {
		this.bookingService = bookingService;
	}

	public GymBookingController(IBookingService bookingService) {
		super();
		this.bookingService = bookingService;
	}

	public GymBookingController()
	{
		
	}
	
//=============================================================================
	
	@RequestMapping("addCustomer")
	public String getAddCustomerPage(Model model)

	{
		//Creating list for GymNames
		List<String> gymNames = new ArrayList<>();
		gymNames.add("Gold Gym");
		gymNames.add("TalwadeKar");
		gymNames.add("Silver Gym");
		gymNames.add("FitNFine Gym");
		
		//Creating List for Timinig
		List<String> timings = new ArrayList<>();
		timings.add("Morning");
		timings.add("Afternoon");
		timings.add("Evening");
		timings.add("Night");
		
		model.addAttribute("gymNames", gymNames);
		model.addAttribute("timinig", timings);
		model.addAttribute("customer", new Customer());
		
		return "AddCustomerPage";
		
	}
	
	@RequestMapping(value="processAddCustomerForm",method=RequestMethod.POST)
	public String getProcessAddCustomerForm(@ModelAttribute("customer") 
									@Valid Customer customer,
									BindingResult result,Model model)
	{
		if(result.hasErrors()==true)
		{
			List<String> gymNames = new ArrayList<>();
			gymNames.add("Gold Gym");
			gymNames.add("TalwadeKar");
			gymNames.add("Silver Gym");
			gymNames.add("FitNFine Gym");
			
			//Creating List for Timinig
			List<String> timings = new ArrayList<>();
			timings.add("Morning");
			timings.add("Afternoon");
			timings.add("Evening");
			timings.add("Night");
			
			model.addAttribute("gymNames", gymNames);
			model.addAttribute("timinig", timings);
			model.addAttribute("customer", customer);
			
			return "AddCustomerPage";
		}
		int custId = -1;
		try
		{
			custId = bookingService.addCustomer(customer);
			System.out.println(custId);
			
		} 
		catch (Exception e)
		{
		//	e.printStackTrace();
			model.addAttribute("errMsg", "Something went wrong while Adding Customer \nReason :"+e.getMessage());
			return "ErrorPage";
		}
		model.addAttribute("message", "Customer Add SuccessFully \n Id :"+custId);
		return "SuccessPage";
		
	}
	@RequestMapping("viewCustomer")
	public String getViewCustomerPage()
	{
		return "ViewCustomerPage";
	}
	
	@RequestMapping(value="proccessViewCustomerDetailsForm", method=RequestMethod.POST)
	public String processViewCustomerForm(@RequestParam("custId") int cid,Model model)
	
	{
		Customer customer= null;
		
		try
		{
			customer = bookingService.getCustomer(cid);
		}
		catch (Exception e)
		{
		//	e.printStackTrace();
			model.addAttribute("errMsg", "Something Went Wrong while Retrieving data"+e.getMessage());
		}
		
		model.addAttribute("customer", customer);
		return "ViewCustomerPage";
		
	}
	
	@RequestMapping("updateCustomer")
	public String getUpdateCustomerPage()
	{
		return "UpdateCustomerPage";
	}
	
	@RequestMapping("UpdateCustomerDetailsForm")
	public String getUpdateForm(@RequestParam("custId") int cid,Model model)
	{
		List<String> gymNames = new ArrayList<>();
		gymNames.add("Gold Gym");
		gymNames.add("TalwadeKar");
		gymNames.add("Silver Gym");
		gymNames.add("FitNFine Gym");
		
		//Creating List for Timinig
		List<String> timings = new ArrayList<>();
		timings.add("Morning");
		timings.add("Afternoon");
		timings.add("Evening");
		timings.add("Night");
		
		Customer cust = null;
		try 
		{
			cust = bookingService.getCustomer(cid);
		} 
		catch (Exception e)
		{
			model.addAttribute("errMsg", "Something Went Wrong while Retrieving data"+e.getMessage());  
		}
	
		model.addAttribute("gymNames", gymNames);
		model.addAttribute("timinig", timings);
		model.addAttribute("cust", cust);
		return "UpdateCustomer";
	}
	
	@RequestMapping(value="ProcessUpdatePageForm",method=RequestMethod.POST)
	public String getProcessUpdatePageForm(@ModelAttribute("cust")
				@Valid Customer customer,BindingResult result,Model model)
	{
		

		if(result.hasErrors()==true)
		{
			List<String> gymNames = new ArrayList<>();
			gymNames.add("Gold Gym");
			gymNames.add("TalwadeKar");
			gymNames.add("Silver Gym");
			gymNames.add("FitNFine Gym");
			
			//Creating List for Timinig
			List<String> timings = new ArrayList<>();
			timings.add("Morning");
			timings.add("Afternoon");
			timings.add("Evening");
			timings.add("Night");
			
			model.addAttribute("gymNames", gymNames);
			model.addAttribute("timinig", timings);
			model.addAttribute("customer", customer);
			
			return "UpdateCustomerPage";
		}
	//	Customer cust= null;
		try
		{
			bookingService.update(customer);
			
		} 
		catch (Exception e)
		{
		//	e.printStackTrace();
			model.addAttribute("errMsg", "Something went wrong while Updating Customer \nReason :"+e.getMessage());
			return "ErrorPage";
		}
		model.addAttribute("message", "Customer Details Update SuccessFully ");
		return "SuccessPage";
	}
}













