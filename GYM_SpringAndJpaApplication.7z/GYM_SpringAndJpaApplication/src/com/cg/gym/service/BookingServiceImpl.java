package com.cg.gym.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.gym.dao.IBookingDao;
import com.cg.gym.entities.Customer;
import com.cg.gym.exception.BookingException;

@Service
@Transactional
public class BookingServiceImpl implements IBookingService {

	
	@Autowired
	private IBookingDao bookingDao;

	public BookingServiceImpl()
	{
		
	}

	public BookingServiceImpl(IBookingDao bookingDao) {
		super();
		this.bookingDao = bookingDao;
	}

	public IBookingDao getBookingDao() {
		return bookingDao;
	}

	public void setBookingDao(IBookingDao bookingDao) {
		this.bookingDao = bookingDao;
	}
//=================================================================================
	@Override
	public int addCustomer(Customer customer) throws BookingException
	{
		// TODO Auto-generated method stub
		return bookingDao.addCustomer(customer);
	}
//-===============================================================================

	@Override
	public Customer getCustomer(int id) throws BookingException {
		// TODO Auto-generated method stub
		return bookingDao.getCustomer(id);
	}

	@Override
	public void update(Customer customer) throws BookingException {
		bookingDao.update(customer);
		
	}
	
	
	
}
