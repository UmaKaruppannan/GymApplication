package com.cg.gym.dao;

import com.cg.gym.entities.Customer;
import com.cg.gym.exception.BookingException;

public interface IBookingDao
{
	public int addCustomer(Customer customer) throws BookingException;
	public Customer getCustomer(int id ) throws BookingException;
	public void update(Customer customer) throws BookingException;
}
