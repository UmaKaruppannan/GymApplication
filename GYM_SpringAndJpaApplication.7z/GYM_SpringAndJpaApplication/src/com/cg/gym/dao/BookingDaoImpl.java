package com.cg.gym.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.gym.entities.Customer;
import com.cg.gym.exception.BookingException;

@Repository
public class BookingDaoImpl implements IBookingDao
{
	@PersistenceContext
	private EntityManager entityManager;
	public BookingDaoImpl()
	{

	}
	public BookingDaoImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() 
	{
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
//===============================================================================
	@Override
	public int addCustomer(Customer customer)
	{
		int bookingid = -1;
		try 
		{
			entityManager.persist(customer);
			bookingid = customer.getId();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new BookingException(e.getMessage());
		}
		return bookingid;
	}
//=================================================================================
	@Override
	public Customer getCustomer(int id) throws BookingException {
		Customer customer = null;
		try 
		{
			customer = entityManager.find(Customer.class, id);
		} 
		catch (Exception e)
		{
			e.printStackTrace();
			throw new BookingException(e.getMessage());
		}
		if(customer == null)
		{
			throw new BookingException("Customer not Found");
		}
		return customer;
		
	}
	@Override
	public void update(Customer customer) throws BookingException {
		try
		{
			entityManager.merge(customer);
			entityManager.flush();
		}
		catch (Exception e) 
		{
			throw new BookingException(e.getMessage());
		}
		
	}

	
	
}
