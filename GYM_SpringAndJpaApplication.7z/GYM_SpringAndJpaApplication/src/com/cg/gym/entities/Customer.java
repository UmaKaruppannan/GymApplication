package com.cg.gym.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name ="CustomerDetails")
public class Customer 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="mygen")
	@SequenceGenerator(name="mygen",sequenceName="custidseq",initialValue=1000)
	private int id;
	
	@NotEmpty(message= "Name Cannot be Empty")
	private String name;
	
	@Min(value=18 ,message ="Age Cannot be less than 18")
	@Max(value=90,message="Age cannot be More than 90")
	private int age;
	
	@NotEmpty(message="Gym name Cannot be Empty")
	private String gym;
	
	@NotEmpty(message="You Hav to select atleast one of the Timinig")
	private String timinigs;
	public Customer() {
		super();
	}
	public Customer(int id, String name, int age, String gym, String timinigs) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.gym = gym;
		this.timinigs = timinigs;
	}
	public Customer(String name, int age, String gym, String timinigs) {
		super();
		this.name = name;
		this.age = age;
		this.gym = gym;
		this.timinigs = timinigs;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGym() {
		return gym;
	}
	public void setGym(String gym) {
		this.gym = gym;
	}
	public String getTiminigs() {
		return timinigs;
	}
	public void setTiminigs(String timinigs) {
		this.timinigs = timinigs;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", age=" + age
				+ ", gym=" + gym + ", timinigs=" + timinigs + "]";
	}
	
	
	
	
}
