create sequence custidseq;

drop sequence custidseq;
select * from CustomerDetails;

insert into CustomerDetails values(101,20,'subbu','GoldGym','Evening');

delete CustomerDetails where id=101;